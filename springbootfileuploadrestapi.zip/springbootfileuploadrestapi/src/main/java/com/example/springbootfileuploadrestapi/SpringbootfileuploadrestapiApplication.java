package com.example.springbootfileuploadrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootfileuploadrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootfileuploadrestapiApplication.class, args);
	}

}
