package com.example.springbootsecurityrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootsecurityrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootsecurityrestapiApplication.class, args);
	}

}
