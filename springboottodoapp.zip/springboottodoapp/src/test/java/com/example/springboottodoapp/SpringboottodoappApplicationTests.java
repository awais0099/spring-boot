package com.example.springboottodoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboottodoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
