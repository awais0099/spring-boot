package com.example.springboottodoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringboottodoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringboottodoappApplication.class, args);
	}

}
