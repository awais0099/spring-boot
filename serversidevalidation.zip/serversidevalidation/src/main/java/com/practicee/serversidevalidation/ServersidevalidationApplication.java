package com.practicee.serversidevalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServersidevalidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServersidevalidationApplication.class, args);
	}

}
