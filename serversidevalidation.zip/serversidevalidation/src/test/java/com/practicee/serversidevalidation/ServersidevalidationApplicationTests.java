package com.practicee.serversidevalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServersidevalidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
