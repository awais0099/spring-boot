package com.example.security2app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Security2appApplication {

	public static void main(String[] args) {
		SpringApplication.run(Security2appApplication.class, args);
	}

}
