package com.example.security5jwtapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Security5jwtappApplication {

	public static void main(String[] args) {
		SpringApplication.run(Security5jwtappApplication.class, args);
	}

}
