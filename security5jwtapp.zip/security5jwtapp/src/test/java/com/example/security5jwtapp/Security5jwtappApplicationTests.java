package com.example.security5jwtapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security5jwtappApplicationTests {

	@Test
	void contextLoads() {
	}

}
