package com.example.security4app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security4appApplicationTests {

	@Test
	void contextLoads() {
	}

}
