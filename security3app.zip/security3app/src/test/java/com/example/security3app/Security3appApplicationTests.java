package com.example.security3app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security3appApplicationTests {

	@Test
	void contextLoads() {
	}

}
