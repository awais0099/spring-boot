package com.example.security3app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Security3appApplication {

	public static void main(String[] args) {
		SpringApplication.run(Security3appApplication.class, args);
	}

}
