package com.example.socialmediaapprestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialmediaapprestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialmediaapprestapiApplication.class, args);
	}

}
