package com.example.springbootJUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJUnitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJUnitApplication.class, args);
	}

}
