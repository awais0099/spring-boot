package com.example.springbootJUnit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJUnitApplicationTests {

	@Test
	void contextLoads() {
	}

}
